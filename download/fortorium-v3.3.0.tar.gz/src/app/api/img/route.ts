import { NextRequest, NextResponse } from 'next/server';

export const maxDuration = 60;

/**
 * API для генерации изображений через Stability AI (Stable Diffusion XL)
 * 
 * Использует переменную окружения STABILITY_API_KEY
 * Fallback на DiceBear и Picsum при отсутствии ключа
 */
export async function POST(request: NextRequest) {
  console.log('[API/img] Image generation request');
  
  try {
    const body = await request.json();
    const { prompt, style = 'ghibli', width = 1024, height = 1024 } = body;
    
    if (!prompt) {
      return NextResponse.json({
        success: false,
        error: 'Prompt is required'
      }, { status: 400 });
    }
    
    // Проверяем наличие Stability AI API key
    const stabilityApiKey = process.env.STABILITY_API_KEY;
    
    if (stabilityApiKey) {
      // Используем Stability AI
      return await generateWithStability(prompt, style, width, height, stabilityApiKey);
    } else {
      // Fallback на бесплатные сервисы
      return await generateWithFallback(prompt, style);
    }
  } catch (error: any) {
    console.error('[API/img] Error:', error);
    return NextResponse.json({
      success: false,
      error: error?.message || String(error)
    }, { status: 500 });
  }
}

/**
 * Генерация через Stability AI (Stable Diffusion XL)
 */
async function generateWithStability(
  prompt: string, 
  style: string, 
  width: number, 
  height: number,
  apiKey: string
): Promise<NextResponse> {
  console.log('[API/img] Using Stability AI');
  
  const stylePrompts: Record<string, string> = {
    ghibli: 'Studio Ghibli style, Miyazaki, watercolor, magical, soft colors, anime, hand-painted',
    disney: 'Disney 2D animation style, classic animation, vibrant colors, expressive characters',
    pixar: 'Pixar 3D style, modern 3D animation, cinematic lighting, detailed textures',
    anime: 'Anime style, Japanese animation, bright colors, stylized, clean lines',
    cartoon: 'Modern cartoon style, bright and colorful, playful, simple shapes',
    watercolor: 'Watercolor painting style, soft edges, flowing colors, artistic',
    retro: 'Retro 80s style, neon colors, synthwave, vintage aesthetic',
    claymation: 'Claymation style, plasticine, stop-motion, Aardman style',
    soviet: 'Soviet animation style, Soyuzmultfilm, warm colors, traditional',
    'soviet-puppet': 'Soviet puppet animation style, Cheburashka, stop-motion, vintage'
  };
  
  const stylePrompt = stylePrompts[style] || stylePrompts.ghibli;
  const fullPrompt = `${stylePrompt}, ${prompt}, high quality, detailed, masterpiece`;
  
  console.log('[API/img] Prompt:', fullPrompt.substring(0, 100) + '...');
  
  try {
    const response = await fetch(
      'https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          text_prompts: [
            {
              text: fullPrompt,
              weight: 1
            },
            {
              text: 'blurry, bad quality, distorted, ugly, deformed',
              weight: -1
            }
          ],
          cfg_scale: 7,
          height: height,
          width: width,
          steps: 30,
          samples: 1,
          style_preset: style === 'anime' ? 'anime' : style === 'pixar' ? '3d-model' : 'cinematic'
        })
      }
    );
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('[API/img] Stability AI error:', response.status, errorText);
      
      // Fallback на бесплатные сервисы
      return await generateWithFallback(prompt, style);
    }
    
    const data = await response.json();
    
    if (data.artifacts && data.artifacts.length > 0) {
      const artifact = data.artifacts[0];
      
      return NextResponse.json({
        success: true,
        imageUrl: `data:image/png;base64,${artifact.base64}`,
        prompt: fullPrompt,
        generator: 'stability-ai',
        seed: artifact.seed
      });
    } else {
      console.error('[API/img] No artifacts in response');
      return await generateWithFallback(prompt, style);
    }
  } catch (error: any) {
    console.error('[API/img] Stability AI request error:', error);
    return await generateWithFallback(prompt, style);
  }
}

/**
 * Fallback на бесплатные сервисы (DiceBear, Pollinations, Picsum)
 */
async function generateWithFallback(
  prompt: string, 
  style: string
): Promise<NextResponse> {
  console.log('[API/img] Using fallback generators');
  
  // Сначала пробуем Pollinations AI (бесплатный)
  try {
    const encodedPrompt = encodeURIComponent(`${style} style, ${prompt}`);
    const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=1024&nologo=true`;
    
    // Проверяем доступность
    const testResponse = await fetch(pollinationsUrl, { method: 'HEAD' });
    
    if (testResponse.ok) {
      return NextResponse.json({
        success: true,
        imageUrl: pollinationsUrl,
        prompt: `${style} style, ${prompt}`,
        generator: 'pollinations'
      });
    }
  } catch (e) {
    console.log('[API/img] Pollinations unavailable, trying next fallback');
  }
  
  // DiceBear для аватаров/персонажей
  const seed = prompt.replace(/\s+/g, '-').substring(0, 30);
  const dicebearUrl = `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${encodeURIComponent(seed)}&backgroundColor=linear-gradient(45deg,%236366f1,%238b5cf6)`;
  
  return NextResponse.json({
    success: true,
    imageUrl: dicebearUrl,
    prompt: prompt,
    generator: 'dicebear-fallback',
    note: 'Using fallback generator. Add STABILITY_API_KEY for better quality images.'
  });
}

/**
 * GET endpoint для проверки статуса API
 */
export async function GET() {
  const hasStabilityKey = !!process.env.STABILITY_API_KEY;
  
  return NextResponse.json({
    success: true,
    status: 'operational',
    generators: {
      stabilityAI: hasStabilityKey,
      pollinations: true,
      dicebear: true
    },
    version: '3.3.0'
  });
}
